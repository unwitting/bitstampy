import calls

# Constants
SORT_ASCENDING = 'asc'
SORT_DESCENDING = 'desc'
TYPE_DEPOSIT = '0'
TYPE_WITHDRAWAL = '1'
TYPE_MARKET_TRADE = '2'
TYPE_BUY = '0'
TYPE_SELL = '1'

WITHDRAWAL_REQUEST_TYPE_SEPA = '0'
WITHDRAWAL_REQUEST_TYPE_BITCOIN = '1'
WITHDRAWAL_REQUEST_TYPE_WIRE = '2'
WITHDRAWAL_REQUEST_TYPE_BITSTAMP_CODE_1 = '3'
WITHDRAWAL_REQUEST_TYPE_BITSTAMP_CODE_2 = '4'
WITHDRAWAL_REQUEST_TYPE_MTGOX = '5'

WITHDRAWAL_REQUEST_STATUS_OPEN = '0'
WITHDRAWAL_REQUEST_STATUS_IN_PROCESS = '1'
WITHDRAWAL_REQUEST_STATUS_FINISHED = '2'
WITHDRAWAL_REQUEST_STATUS_CANCELLED = '3'
WITHDRAWAL_REQUEST_STATUS_FAILED = '4'


# Wrapper functions
def account_balance(client_id, api_key, api_secret):
	return calls.APIAccountBalanceCall().auth(client_id, api_key, api_secret).call()

def bitcoin_deposit_address(client_id, api_key, api_secret):
	return calls.APIBitcoinDepositAddressCall().auth(client_id, api_key, api_secret).call()

def buy_limit_order(client_id, api_key, api_secret, amount, price):
	return calls.APIBuyLimitOrderCall().auth(client_id, api_key, api_secret).call({
		'amount': amount, 'price': price
	})

def cancel_order(client_id, api_key, api_secret, order_id):
	return calls.APICancelOrderCall().auth(client_id, api_key, api_secret).call({
		'id': order_id
	})

def check_bitstamp_code(client_id, api_key, api_secret, code):
	return calls.APICheckBitstampCodeCall().auth(client_id, api_key, api_secret).call({
		'code': code
	})

def eur_usd_conversion_rate(): return calls.APIEURUSDConversionRateCall().call()

def open_orders(client_id, api_key, api_secret):
	return calls.APIOpenOrdersCall().auth(client_id, api_key, api_secret).call()

def order_book(group = True):
	return calls.APIOrderBookCall().call({
		'group': '1' if group else '0'
	})

def redeem_bitstamp_code(client_id, api_key, api_secret, code):
	return calls.APIRedeemBitstampCodeCall().auth(client_id, api_key, api_secret).call({
		'code': code
	})

def ripple_deposit_address(client_id, api_key, api_secret):
	return calls.APIRippleDepositAddressCall().auth(client_id, api_key, api_secret).call()

def ripple_withdrawal(client_id, api_key, api_secret, amount, address, currency):
	return calls.APIRippleWithdrawalCall().auth(client_id, api_key, api_secret).call()

def sell_limit_order(client_id, api_key, api_secret, amount, price):
	return calls.APISellLimitOrderCall().auth(client_id, api_key, api_secret).call({
		'amount': amount, 'price': price
	})

def ticker(): return calls.APITickerCall().call()

def transactions(offset = 0, limit = 100, sort = SORT_DESCENDING):
	return calls.APITransactionsCall().call({
		'offset': offset, 'limit': limit, 'sort': sort
	})

def unconfirmed_bitcoin_deposits(client_id, api_key, api_secret):
	return calls.APIUnconfirmedBitcoinDepositsCall().auth(
		client_id, api_key, api_secret).call()

def user_transactions(client_id, api_key, api_secret, 
	offset = 0, limit = 100, sort = SORT_DESCENDING):
	return calls.APIUserTransactionsCall().auth(client_id, api_key, api_secret).call({
		'offset': offset, 'limit': limit, 'sort': sort
	})

def withdrawal(client_id, api_key, api_secret, amount, address):
	return calls.APIWithdrawalCall().auth(client_id, api_key, api_secret).call({
		'amount': amount,
		'address': address
	})

def withdrawal_requests(client_id, api_key, api_secret):
	return calls.APIWithdrawalRequestsCall().auth(client_id, api_key, api_secret).call()
